import { Transaction, MemberRecord } from '../types';
import { formatDateDDMMYYYY, formatDateTimeDDMMYYYY } from './date';
import { isTransactionInMonth, getTransactionMonthInfo } from './monthHelper';

export interface MatrixRow {
  donorName: string;
  categoryAmounts: { [category: string]: number };
  total: number;
  isAnonymous?: boolean;
  paymentMethods: ('online' | 'cash')[];
  paymentMethodLabel: 'ONLINE' | 'CASH' | 'ONLINE + CASH';
  remarks?: string[];
}

export interface KumtluangMatrixData {
  categories: string[];
  rows: MatrixRow[];
  columnTotals: { [category: string]: number };
  grandTotal: number;
  onlineTotal: number;
  cashTotal: number;
}

export const ALL_MONTH_NAMES_SHORT = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'] as const;

export interface MonthRangeConfig {
  startMonth?: string;
  endMonth?: string;
  preset?: string;
}

export interface TargetExportInfo {
  targetAmount: number;
  targetPeriod?: 'monthly' | 'yearly' | 'total' | string;
  periodLabel?: string;
  periodSuffix?: string;
  progressPct?: number;
  isCompleted?: boolean;
  remaining?: number;
  surplus?: number;
  campaignTitle?: string;
}

export interface PDFExportOptions {
  includeMonthlyChart?: boolean;
  monthRangeConfig?: MonthRangeConfig;
  includeSignatures?: boolean;
  groupByDonor?: boolean;
  showDateTime?: boolean;
  members?: MemberRecord[];
  preparedByTitle?: string;
  verifiedByTitle?: string;
  approvedByTitle?: string;
  targetInfo?: TargetExportInfo;
}

export interface GroupedDonorRecord {
  donorName: string;
  isAnonymous: boolean;
  memberId?: string;
  section?: string;
  phone?: string;
  donorMemberId?: string;
  donorSection?: string;
  donorPhone?: string;
  paymentMethods: ('online' | 'cash')[];
  paymentMethodLabel: 'ONLINE' | 'CASH' | 'ONLINE + CASH';
  totalAmount: number;
  transactionsCount: number;
  txCount: number;
  transactions: Transaction[];
  monthsPaid: string[];
  datesPaid: string[];
  dateRange: string;
  categoryBreakdown: { [category: string]: number };
  remarks: string[];
}

/**
 * Universal safe print trigger that opens the high-resolution Print Preview screen.
 * Dispatches the event so users can inspect, review, zoom, and decide when to trigger printing.
 */
export const printHtmlSafely = (html: string, docTitle: string = 'Print Document') => {
  if (typeof window !== 'undefined') {
    try {
      window.dispatchEvent(new CustomEvent('ronpay-open-print-modal', {
        detail: { html, docTitle }
      }));
    } catch (e) {
      console.warn('Print modal event dispatch failed', e);
    }
  }
};

/**
 * Universal File Download & Share helper:
 * 1. Checks if Web Share API (navigator.share) is available with files on Mobile / Android WebViews.
 * 2. Fallback to standard Blob URL & <a> download click.
 * 3. Fallback to Base64 Data URI for WebViews without Blob download support.
 */
export const downloadFileUniversal = async (
  content: string | Blob,
  fileName: string,
  mimeType: string,
  _title: string = 'RonPay Report'
): Promise<boolean> => {
  try {
    const blob = content instanceof Blob 
      ? content 
      : new Blob([mimeType.includes('charset') ? '\uFEFF' + content : content], { type: mimeType });

    const isMobile = typeof navigator !== 'undefined' && /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent || '');

    // Step 1: Standard Blob Object URL with direct anchor download
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();

    setTimeout(() => {
      try {
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      } catch (e) {
        // ignore cleanup error
      }
    }, 2500);

    // Step 2: Base64 Data URI fallback for Android WebViews that restrict Blob downloads
    if (typeof content === 'string') {
      try {
        const dataUri = `data:${mimeType};charset=utf-8,` + encodeURIComponent(content);
        const fallbackA = document.createElement('a');
        fallbackA.href = dataUri;
        fallbackA.download = fileName;
        fallbackA.style.display = 'none';
        document.body.appendChild(fallbackA);
        fallbackA.click();
        setTimeout(() => {
          try {
            document.body.removeChild(fallbackA);
          } catch (e) {}
        }, 1200);
      } catch (e) {}
    } else if (blob instanceof Blob && isMobile) {
      // For binary blobs (like PDF) in Android WebViews:
      try {
        const reader = new FileReader();
        reader.onloadend = () => {
          if (reader.result && typeof reader.result === 'string') {
            const fbLink = document.createElement('a');
            fbLink.href = reader.result;
            fbLink.download = fileName;
            fbLink.style.display = 'none';
            document.body.appendChild(fbLink);
            fbLink.click();
            setTimeout(() => {
              try { document.body.removeChild(fbLink); } catch {}
            }, 1200);
          }
        };
        reader.readAsDataURL(blob);
      } catch (e) {}
    }

    return true;
  } catch (err) {
    console.error('downloadFileUniversal error:', err);
    return false;
  }
};

/**
 * Returns the ordered array of month abbreviations for a given From - Upto month configuration.
 */
export const getMonthsListForConfig = (config?: MonthRangeConfig): string[] => {
  const start = config?.startMonth || 'Jan';
  const end = config?.endMonth || 'Dec';
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  
  const sIdx = months.indexOf(start);
  const eIdx = months.indexOf(end);
  if (sIdx === -1 || eIdx === -1) {
    return ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  }
  
  if (sIdx === eIdx) {
    return [start]; // Single month (e.g. From Aug Upto Aug)
  }
  if (sIdx < eIdx) {
    return months.slice(sIdx, eIdx + 1);
  } else {
    // Wrap around (e.g., Apr to Mar => Apr..Dec, Jan..Mar)
    return [...months.slice(sIdx), ...months.slice(0, eIdx + 1)];
  }
};

/**
 * Builds a donor-by-category matrix specifically for Kumtluang Bawm / multi-category campaigns.
 */
export const buildKumtluangMatrix = (
  transactions: Transaction[],
  sortOrder?: 'date-desc' | 'name-asc' | 'name-desc' | 'amount-desc',
  preferredCategories?: string[]
): KumtluangMatrixData => {
  const categorySet = new Set<string>();
  if (preferredCategories && Array.isArray(preferredCategories) && preferredCategories.length > 0) {
    preferredCategories.forEach(cat => {
      if (cat && cat.trim()) categorySet.add(cat.trim());
    });
  }

  const donorMap = new Map<string, { [cat: string]: number }>();
  const donorPaymentMethods = new Map<string, Set<'online' | 'cash'>>();
  const donorRemarks = new Map<string, string[]>();

  let onlineTotal = 0;
  let cashTotal = 0;

  transactions.forEach(t => {
    const donor = t.isAnonymous ? 'Anonymous' : (t.donorName || 'Unknown Donor');
    const method: 'online' | 'cash' = t.paymentMethod === 'cash' ? 'cash' : 'online';

    if (method === 'online') {
      onlineTotal += t.amount;
    } else {
      cashTotal += t.amount;
    }

    if (!donorPaymentMethods.has(donor)) {
      donorPaymentMethods.set(donor, new Set());
    }
    donorPaymentMethods.get(donor)!.add(method);

    if (t.remark && t.remark.trim()) {
      if (!donorRemarks.has(donor)) {
        donorRemarks.set(donor, []);
      }
      const cleanRemark = t.remark.trim();
      if (!donorRemarks.get(donor)!.includes(cleanRemark)) {
        donorRemarks.get(donor)!.push(cleanRemark);
      }
    }

    if (!donorMap.has(donor)) {
      donorMap.set(donor, {});
    }
    const donorCats = donorMap.get(donor)!;

    if (t.subCategoryBreakdown && Object.keys(t.subCategoryBreakdown).length > 0) {
      Object.entries(t.subCategoryBreakdown).forEach(([cat, amt]) => {
        const cleanCat = cat.trim();
        const numAmt = Number(amt) || 0;
        if (numAmt > 0) {
          categorySet.add(cleanCat);
          donorCats[cleanCat] = (donorCats[cleanCat] || 0) + numAmt;
        }
      });
    } else {
      const fallbackCat = (preferredCategories && preferredCategories.length > 0)
        ? preferredCategories[0]
        : (t.subCategory || t.campaignTitle || 'General Collection');
      categorySet.add(fallbackCat);
      donorCats[fallbackCat] = (donorCats[fallbackCat] || 0) + t.amount;
    }
  });

  const categories = Array.from(categorySet);
  const rows: MatrixRow[] = [];
  const columnTotals: { [category: string]: number } = {};
  categories.forEach(c => { columnTotals[c] = 0; });
  let grandTotal = 0;

  donorMap.forEach((catAmounts, donorName) => {
    let rowTotal = 0;
    const cleanCatAmounts: { [category: string]: number } = {};

    categories.forEach(c => {
      const amt = catAmounts[c] || 0;
      cleanCatAmounts[c] = amt;
      rowTotal += amt;
      columnTotals[c] += amt;
    });

    grandTotal += rowTotal;

    const methodsSet = donorPaymentMethods.get(donorName) || new Set<'online' | 'cash'>(['online']);
    const methodsArr = Array.from(methodsSet);
    let methodLabel: 'ONLINE' | 'CASH' | 'ONLINE + CASH' = 'ONLINE';
    if (methodsSet.has('online') && methodsSet.has('cash')) {
      methodLabel = 'ONLINE + CASH';
    } else if (methodsSet.has('cash')) {
      methodLabel = 'CASH';
    } else {
      methodLabel = 'ONLINE';
    }

    const remarksList = donorRemarks.get(donorName);

    rows.push({
      donorName,
      categoryAmounts: cleanCatAmounts,
      total: rowTotal,
      paymentMethods: methodsArr,
      paymentMethodLabel: methodLabel,
      remarks: remarksList && remarksList.length > 0 ? remarksList : undefined,
    });
  });

  // Apply sorting to matrix rows
  if (sortOrder === 'name-asc') {
    rows.sort((a, b) => a.donorName.localeCompare(b.donorName));
  } else if (sortOrder === 'name-desc') {
    rows.sort((a, b) => b.donorName.localeCompare(a.donorName));
  } else if (sortOrder === 'amount-desc') {
    rows.sort((a, b) => b.total - a.total);
  }

  return {
    categories,
    rows,
    columnTotals,
    grandTotal,
    onlineTotal,
    cashTotal,
  };
};

/**
 * Groups and aggregates transactions by Donor / Member into consolidated single-row records.
 * Solves the issue of multiple transactions for the same donor cluttering statements or tables.
 */
export const buildGroupedDonorRecords = (
  transactions: Transaction[],
  sortOrder?: 'date-desc' | 'name-asc' | 'name-desc' | 'amount-desc'
): GroupedDonorRecord[] => {
  const donorMap = new Map<string, {
    donorName: string;
    isAnonymous: boolean;
    memberId?: string;
    section?: string;
    phone?: string;
    paymentMethods: Set<'online' | 'cash'>;
    totalAmount: number;
    transactions: Transaction[];
    monthsSet: Set<string>;
    datesList: Date[];
    categoryBreakdown: { [cat: string]: number };
    remarksSet: Set<string>;
  }>();

  transactions.forEach(t => {
    const rawName = t.isAnonymous ? 'Anonymous' : (t.donorName?.trim() || 'Unknown Donor');
    // Group key: normalize donor name
    const groupKey = rawName.toLowerCase();

    if (!donorMap.has(groupKey)) {
      donorMap.set(groupKey, {
        donorName: rawName,
        isAnonymous: Boolean(t.isAnonymous),
        memberId: t.memberId || undefined,
        section: t.donorVeng || undefined,
        phone: t.donorPhone || undefined,
        paymentMethods: new Set<'online' | 'cash'>(),
        totalAmount: 0,
        transactions: [],
        monthsSet: new Set<string>(),
        datesList: [],
        categoryBreakdown: {},
        remarksSet: new Set<string>(),
      });
    }

    const donorRec = donorMap.get(groupKey)!;
    donorRec.totalAmount += (t.amount || 0);
    donorRec.transactions.push(t);

    if (t.memberId && !donorRec.memberId) {
      donorRec.memberId = t.memberId;
    }
    if (t.donorVeng && !donorRec.section) {
      donorRec.section = t.donorVeng;
    }
    if (t.donorPhone && !donorRec.phone) {
      donorRec.phone = t.donorPhone;
    }

    const method: 'online' | 'cash' = t.paymentMethod === 'cash' ? 'cash' : 'online';
    donorRec.paymentMethods.add(method);

    // Track month / period label
    const mInfo = getTransactionMonthInfo(t);
    const mLabel = t.periodLabel || `${mInfo.shortMonth} ${mInfo.year}`;
    donorRec.monthsSet.add(mLabel);

    try {
      const d = new Date(t.timestamp);
      if (!isNaN(d.getTime())) {
        donorRec.datesList.push(d);
      }
    } catch {}

    // Track category breakdown
    if (t.subCategoryBreakdown && typeof t.subCategoryBreakdown === 'object') {
      Object.entries(t.subCategoryBreakdown).forEach(([k, v]) => {
        const amt = Number(v) || 0;
        if (amt > 0) {
          donorRec.categoryBreakdown[k] = (donorRec.categoryBreakdown[k] || 0) + amt;
        }
      });
    } else if (t.subCategory) {
      donorRec.categoryBreakdown[t.subCategory] = (donorRec.categoryBreakdown[t.subCategory] || 0) + t.amount;
    }

    if (t.remark && t.remark.trim()) {
      donorRec.remarksSet.add(t.remark.trim());
    }
  });

  const records: GroupedDonorRecord[] = [];

  donorMap.forEach(d => {
    const methodsArr = Array.from(d.paymentMethods);
    let methodLabel: 'ONLINE' | 'CASH' | 'ONLINE + CASH' = 'ONLINE';
    if (d.paymentMethods.has('online') && d.paymentMethods.has('cash')) {
      methodLabel = 'ONLINE + CASH';
    } else if (d.paymentMethods.has('cash')) {
      methodLabel = 'CASH';
    } else {
      methodLabel = 'ONLINE';
    }

    // Determine date range text
    let dateRange = '';
    if (d.datesList.length === 1) {
      dateRange = formatDateDDMMYYYY(d.datesList[0]);
    } else if (d.datesList.length > 1) {
      const sortedDates = [...d.datesList].sort((a, b) => a.getTime() - b.getTime());
      const minD = formatDateDDMMYYYY(sortedDates[0]);
      const maxD = formatDateDDMMYYYY(sortedDates[sortedDates.length - 1]);
      dateRange = minD === maxD ? minD : `${minD} - ${maxD}`;
    }

    const uniqueDatesFormatted = Array.from(
      new Set(d.datesList.map(dt => formatDateDDMMYYYY(dt)))
    );

    records.push({
      donorName: d.donorName,
      isAnonymous: d.isAnonymous,
      memberId: d.memberId,
      section: d.section,
      phone: d.phone,
      donorMemberId: d.memberId,
      donorSection: d.section,
      donorPhone: d.phone,
      paymentMethods: methodsArr,
      paymentMethodLabel: methodLabel,
      totalAmount: d.totalAmount,
      transactionsCount: d.transactions.length,
      txCount: d.transactions.length,
      transactions: d.transactions.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()),
      monthsPaid: Array.from(d.monthsSet),
      datesPaid: uniqueDatesFormatted,
      dateRange,
      categoryBreakdown: d.categoryBreakdown || {},
      remarks: Array.from(d.remarksSet),
    });
  });

  // Apply sorting
  if (sortOrder === 'name-asc') {
    records.sort((a, b) => a.donorName.localeCompare(b.donorName));
  } else if (sortOrder === 'name-desc') {
    records.sort((a, b) => b.donorName.localeCompare(a.donorName));
  } else if (sortOrder === 'amount-desc') {
    records.sort((a, b) => b.totalAmount - a.totalAmount);
  } else {
    // date-desc (newest payment first)
    records.sort((a, b) => {
      const timeA = a.transactions[0] ? new Date(a.transactions[0].timestamp).getTime() : 0;
      const timeB = b.transactions[0] ? new Date(b.transactions[0].timestamp).getTime() : 0;
      return timeB - timeA;
    });
  }

  return records;
};

/**
 * Computes monthly distribution for the visual bar chart based on selected month configuration
 */
export const computeMonthlyDistribution = (
  transactions: Transaction[],
  config?: MonthRangeConfig
) => {
  const months = getMonthsListForConfig(config);
  const monthTotals: Record<string, number> = {};
  months.forEach(m => { monthTotals[m] = 0; });

  transactions.forEach(t => {
    try {
      const monthInfo = getTransactionMonthInfo(t);
      const mName = monthInfo.shortMonth;
      if (monthTotals[mName] !== undefined) {
        monthTotals[mName] += (t.amount || 0);
      }
    } catch {
      // fallback
    }
  });

  const maxVal = Math.max(...Object.values(monthTotals), 1);
  return {
    months,
    monthTotals,
    maxVal,
  };
};

/**
 * Exports formatted XML/HTML Excel Workbook (.xls) with custom cell styles, colors, borders, and currency formats.
 */
export const exportFormattedExcel = (
  transactions: Transaction[],
  title: string = 'RonPay_Formatted_Report',
  isKumtluang: boolean = false,
  campaignName: string = 'All Campaigns',
  dateRangeText: string = 'All Time',
  creatorInfo?: { name: string; orgName: string; phone: string; address?: string },
  sortOrder?: 'date-desc' | 'name-asc' | 'name-desc' | 'amount-desc',
  targetInfo?: TargetExportInfo
) => {
  const orgName = creatorInfo?.orgName?.trim() || (campaignName && campaignName !== 'All Campaigns' ? campaignName : '') || creatorInfo?.name?.trim() || 'RONPAY ORGANIZATION';
  const location = creatorInfo?.address?.trim() || 'Mizoram, India';
  const totalAmount = transactions.reduce((sum, t) => sum + t.amount, 0);

  const onlineTransactions = transactions.filter(t => t.paymentMethod === 'online');
  const cashTransactions = transactions.filter(t => t.paymentMethod === 'cash');
  const onlineTotal = onlineTransactions.reduce((sum, t) => sum + t.amount, 0);
  const cashTotal = cashTransactions.reduce((sum, t) => sum + t.amount, 0);

  let tableContentHtml = '';

  if (isKumtluang) {
    const matrix = buildKumtluangMatrix(transactions, sortOrder);
    const colCount = matrix.categories.length + 3; // SlNo + Hming + PaymentMode + categories + Total

    const catHeaders = matrix.categories.map(c => 
      `<th class="header-cat">${c.toUpperCase()}</th>`
    ).join('');

    const dataRows = matrix.rows.map((r, idx) => {
      const modeText = r.paymentMethodLabel === 'ONLINE' ? '⚡ ONLINE' : r.paymentMethodLabel === 'CASH' ? '💵 CASH' : '⚡+💵 ONLINE & CASH';
      return `
      <tr class="${idx % 2 === 0 ? 'row-even' : 'row-odd'}">
        <td class="cell-center cell-bold">${idx + 1}</td>
        <td class="cell-left cell-bold">${r.donorName}</td>
        <td class="cell-center cell-mode ${r.paymentMethodLabel === 'CASH' ? 'mode-cash' : 'mode-online'}">${modeText}</td>
        ${matrix.categories.map(c => `
          <td class="cell-currency">${r.categoryAmounts[c] || 0}</td>
        `).join('')}
        <td class="cell-currency-total">${r.total}</td>
      </tr>
    `;
    }).join('');

    const totalCols = matrix.categories.map(c => `
      <td class="cell-grand-currency">${matrix.columnTotals[c] || 0}</td>
    `).join('');

    const targetRowsHtml = targetInfo && targetInfo.targetAmount > 0 ? `
        <tr class="meta-row">
          <td colspan="2" class="meta-header">🎯 Target Goal:</td>
          <td colspan="${colCount - 2}" class="meta-data">INR ${targetInfo.targetAmount.toLocaleString('en-IN')}${targetInfo.periodSuffix || ''} (${targetInfo.periodLabel || 'Target'})</td>
        </tr>
        <tr class="meta-row">
          <td colspan="2" class="meta-header">📈 Target Achievement:</td>
          <td colspan="${colCount - 2}" class="meta-data-highlight">${targetInfo.progressPct ?? Math.round((matrix.grandTotal / targetInfo.targetAmount) * 100)}% Collected (${matrix.grandTotal >= targetInfo.targetAmount ? `Goal Achieved (+INR ${(matrix.grandTotal - targetInfo.targetAmount).toLocaleString('en-IN')} surplus)` : `INR ${(targetInfo.targetAmount - matrix.grandTotal).toLocaleString('en-IN')} Remaining`})</td>
        </tr>
    ` : '';

    tableContentHtml = `
      <table class="report-table">
        <!-- Title Banner -->
        <tr>
          <th colspan="${colCount}" class="title-banner">${orgName.toUpperCase()}</th>
        </tr>
        <tr>
          <td colspan="${colCount}" class="subtitle-banner">📍 ${location}</td>
        </tr>
        <tr>
          <td colspan="${colCount}" class="badge-banner">REPORTS & FINANCIAL STATEMENTS</td>
        </tr>
        <tr>
          <td colspan="${colCount}" class="date-banner">Trxn Date: ${dateRangeText}</td>
        </tr>
        <tr><td colspan="${colCount}" class="empty-row"></td></tr>

        <!-- Meta Summary Grid -->
        <tr class="meta-row">
          <td colspan="2" class="meta-header">NGO / Church / Title:</td>
          <td colspan="${colCount - 2}" class="meta-data">${orgName}</td>
        </tr>
        <tr class="meta-row">
          <td colspan="2" class="meta-header">Veng / Khua / Location:</td>
          <td colspan="${colCount - 2}" class="meta-data">${location}</td>
        </tr>
        <tr class="meta-row">
          <td colspan="2" class="meta-header">Document Type:</td>
          <td colspan="${colCount - 2}" class="meta-data">Reports & Financial Statements</td>
        </tr>
        <tr class="meta-row">
          <td colspan="2" class="meta-header">Trxn Date:</td>
          <td colspan="${colCount - 2}" class="meta-data">${dateRangeText}</td>
        </tr>
        <tr class="meta-row">
          <td colspan="2" class="meta-header">Total Donors:</td>
          <td colspan="${colCount - 2}" class="meta-data">${matrix.rows.length} Donors</td>
        </tr>
        <tr class="meta-row">
          <td colspan="2" class="meta-header">⚡ Online Collection (UPI):</td>
          <td colspan="${colCount - 2}" class="meta-data-online">INR ${matrix.onlineTotal.toLocaleString('en-IN')}</td>
        </tr>
        <tr class="meta-row">
          <td colspan="2" class="meta-header">💵 Cash Collection (Counter):</td>
          <td colspan="${colCount - 2}" class="meta-data-cash">INR ${matrix.cashTotal.toLocaleString('en-IN')}</td>
        </tr>
        <tr class="meta-row">
          <td colspan="2" class="meta-header">Grand Total Collection:</td>
          <td colspan="${colCount - 2}" class="meta-data-highlight">INR ${matrix.grandTotal.toLocaleString('en-IN')}</td>
        </tr>
        ${targetRowsHtml}
        <tr class="meta-row">
          <td colspan="2" class="meta-header">Exported At:</td>
          <td colspan="${colCount - 2}" class="meta-data">${formatDateTimeDDMMYYYY(new Date().toISOString())}</td>
        </tr>
        <tr><td colspan="${colCount}" class="empty-row"></td></tr>

        <!-- Data Headers -->
        <thead>
          <tr>
            <th class="header-sl">SL NO.</th>
            <th class="header-name">HMING (DONOR)</th>
            <th class="header-mode">PAYMENT MODE</th>
            ${catHeaders}
            <th class="header-total">TOTAL (₹)</th>
          </tr>
        </thead>
        <tbody>
          ${dataRows}
        </tbody>
        <tfoot>
          <tr>
            <td colspan="3" class="cell-grand-label">GRAND TOTAL</td>
            ${totalCols}
            <td class="cell-grand-highlight">${matrix.grandTotal}</td>
          </tr>
        </tfoot>
      </table>
    `;
  } else {
    // Standard Itemized Sheet
    const colCount = 7;
    const dataRows = transactions.map((t, idx) => {
      let remarks = t.periodLabel || '';
      if (t.remark && t.remark.trim()) {
        remarks = remarks ? `${remarks} • Note: ${t.remark.trim()}` : t.remark.trim();
      }
      if (t.subCategoryBreakdown && Object.keys(t.subCategoryBreakdown).length > 0) {
        const parts = Object.entries(t.subCategoryBreakdown).map(([k, v]) => `${k}: ${v}`);
        remarks = remarks ? `${remarks} (${parts.join(', ')})` : parts.join(', ');
      }

      const modeText = t.paymentMethod === 'cash' ? '💵 CASH' : '⚡ ONLINE';

      return `
        <tr class="${idx % 2 === 0 ? 'row-even' : 'row-odd'}">
          <td class="cell-center cell-bold">${idx + 1}</td>
          <td class="cell-center cell-date">${formatDateTimeDDMMYYYY(t.timestamp)}</td>
          <td class="cell-left cell-bold">${t.isAnonymous ? 'Anonymous' : t.donorName}</td>
          <td class="cell-center cell-mode ${t.paymentMethod === 'cash' ? 'mode-cash' : 'mode-online'}">${modeText}</td>
          <td class="cell-left">${remarks || '-'}</td>
          <td class="cell-center cell-hash">${t.txHash || t.id}</td>
          <td class="cell-currency-total">${t.amount}</td>
        </tr>
      `;
    }).join('');

    tableContentHtml = `
      <table class="report-table">
        <!-- Title Banner -->
        <tr>
          <th colspan="${colCount}" class="title-banner">${orgName.toUpperCase()}</th>
        </tr>
        <tr>
          <td colspan="${colCount}" class="subtitle-banner">📍 ${location}</td>
        </tr>
        <tr>
          <td colspan="${colCount}" class="badge-banner">REPORTS & FINANCIAL STATEMENTS</td>
        </tr>
        <tr>
          <td colspan="${colCount}" class="date-banner">Trxn Date: ${dateRangeText}</td>
        </tr>
        <tr><td colspan="${colCount}" class="empty-row"></td></tr>

        <!-- Meta Summary Grid -->
        <tr class="meta-row">
          <td colspan="2" class="meta-header">NGO / Church / Title:</td>
          <td colspan="${colCount - 2}" class="meta-data">${orgName}</td>
        </tr>
        <tr class="meta-row">
          <td colspan="2" class="meta-header">Veng / Khua / Location:</td>
          <td colspan="${colCount - 2}" class="meta-data">${location}</td>
        </tr>
        <tr class="meta-row">
          <td colspan="2" class="meta-header">Document Type:</td>
          <td colspan="${colCount - 2}" class="meta-data">Reports & Financial Statements</td>
        </tr>
        <tr class="meta-row">
          <td colspan="2" class="meta-header">Trxn Date:</td>
          <td colspan="${colCount - 2}" class="meta-data">${dateRangeText}</td>
        </tr>
        <tr class="meta-row">
          <td colspan="2" class="meta-header">Total Transactions:</td>
          <td colspan="${colCount - 2}" class="meta-data">${transactions.length} Entries</td>
        </tr>
        <tr class="meta-row">
          <td colspan="2" class="meta-header">⚡ Online Collection (UPI):</td>
          <td colspan="${colCount - 2}" class="meta-data-online">INR ${onlineTotal.toLocaleString('en-IN')} (${onlineTransactions.length} txns)</td>
        </tr>
        <tr class="meta-row">
          <td colspan="2" class="meta-header">💵 Cash Collection (Counter):</td>
          <td colspan="${colCount - 2}" class="meta-data-cash">INR ${cashTotal.toLocaleString('en-IN')} (${cashTransactions.length} txns)</td>
        </tr>
        <tr class="meta-row">
          <td colspan="2" class="meta-header">Grand Total Collection:</td>
          <td colspan="${colCount - 2}" class="meta-data-highlight">INR ${totalAmount.toLocaleString('en-IN')}</td>
        </tr>
        ${targetInfo && targetInfo.targetAmount > 0 ? `
        <tr class="meta-row">
          <td colspan="2" class="meta-header">🎯 Target Goal:</td>
          <td colspan="${colCount - 2}" class="meta-data">INR ${targetInfo.targetAmount.toLocaleString('en-IN')}${targetInfo.periodSuffix || ''} (${targetInfo.periodLabel || 'Target'})</td>
        </tr>
        <tr class="meta-row">
          <td colspan="2" class="meta-header">📈 Target Achievement:</td>
          <td colspan="${colCount - 2}" class="meta-data-highlight">${targetInfo.progressPct ?? Math.round((totalAmount / targetInfo.targetAmount) * 100)}% Collected (${totalAmount >= targetInfo.targetAmount ? `Goal Achieved (+INR ${(totalAmount - targetInfo.targetAmount).toLocaleString('en-IN')} surplus)` : `INR ${(targetInfo.targetAmount - totalAmount).toLocaleString('en-IN')} Remaining`})</td>
        </tr>
        ` : ''}
        <tr class="meta-row">
          <td colspan="2" class="meta-header">Exported At:</td>
          <td colspan="${colCount - 2}" class="meta-data">${formatDateTimeDDMMYYYY(new Date().toISOString())}</td>
        </tr>
        <tr><td colspan="${colCount}" class="empty-row"></td></tr>

        <!-- Data Headers -->
        <thead>
          <tr>
            <th class="header-sl">SL NO.</th>
            <th class="header-date">DATE & TIME</th>
            <th class="header-name">HMING (DONOR)</th>
            <th class="header-mode">PAYMENT MODE</th>
            <th class="header-remarks">REMARKS / NOTE</th>
            <th class="header-ref">TX HASH / ID</th>
            <th class="header-total">AMOUNT (₹)</th>
          </tr>
        </thead>
        <tbody>
          ${dataRows}
        </tbody>
        <tfoot>
          <tr>
            <td colspan="6" class="cell-grand-label">GRAND TOTAL COLLECTION</td>
            <td class="cell-grand-highlight">${totalAmount}</td>
          </tr>
        </tfoot>
      </table>
    `;
  }

  const excelTemplate = `
    <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
      <head>
        <meta http-equiv="content-type" content="text/plain; charset=UTF-8"/>
        <!--[if gte mso 9]>
        <xml>
          <x:ExcelWorkbook>
            <x:ExcelWorksheets>
              <x:ExcelWorksheet>
                <x:Name>${(campaignName || 'Report').slice(0, 31).replace(/[:\\\/?*\[\]]/g, '')}</x:Name>
                <x:WorksheetOptions>
                  <x:DisplayGridlines/>
                </x:WorksheetOptions>
              </x:ExcelWorksheet>
            </x:ExcelWorksheets>
          </x:ExcelWorkbook>
        </xml>
        <![endif]-->
        <style>
          .report-table { border-collapse: collapse; width: 100%; font-family: 'Segoe UI', Arial, sans-serif; font-size: 10pt; }
          .title-banner { background-color: #0f172a; color: #ffffff; font-size: 15pt; font-weight: bold; text-align: center; height: 36px; }
          .subtitle-banner { background-color: #1e293b; color: #fef08a; font-size: 10pt; font-weight: bold; text-align: center; height: 24px; }
          .badge-banner { background-color: #0284c7; color: #ffffff; font-size: 9.5pt; font-weight: bold; text-align: center; height: 20px; }
          .date-banner { background-color: #0f172a; color: #cbd5e1; font-size: 9pt; font-weight: bold; text-align: center; height: 20px; }
          .empty-row { height: 12px; }
          
          .meta-header { background-color: #f1f5f9; color: #334155; font-weight: bold; border: 0.5pt solid #cbd5e1; padding: 4px 8px; font-size: 9pt; }
          .meta-data { background-color: #ffffff; color: #0f172a; font-weight: bold; border: 0.5pt solid #cbd5e1; padding: 4px 8px; font-size: 9pt; }
          .meta-data-highlight { background-color: #dcfce7; color: #166534; font-weight: bold; border: 0.5pt solid #cbd5e1; padding: 4px 8px; font-size: 10pt; }

          th { background-color: #1e1b4b; color: #ffffff; font-weight: bold; font-size: 9.5pt; text-align: center; border: 0.5pt solid #4338ca; height: 28px; padding: 6px; }
          .header-sl { width: 50px; }
          .header-name { width: 220px; text-align: left; padding-left: 8px; }
          .header-cat { width: 130px; text-align: right; padding-right: 8px; }
          .header-total { width: 130px; text-align: right; background-color: #312e81; padding-right: 8px; }
          .header-date { width: 140px; }
          .header-mode { width: 90px; }
          .header-remarks { width: 200px; text-align: left; }
          .header-ref { width: 140px; }

          .row-even { background-color: #ffffff; }
          .row-odd { background-color: #f8fafc; }

          td { border: 0.5pt solid #e2e8f0; padding: 5px 8px; font-size: 9.5pt; }
          .cell-center { text-align: center; }
          .cell-left { text-align: left; }
          .cell-bold { font-weight: bold; color: #0f172a; }
          .cell-date { mso-number-format:"\@"; color: #475569; }
          .cell-mode { font-weight: bold; color: #166534; }
          .cell-hash { font-family: monospace; font-size: 8.5pt; color: #64748b; mso-number-format:"\@"; }
          
          .cell-currency { text-align: right; font-weight: 600; color: #0f172a; mso-number-format:"\#\,\#\#0"; }
          .cell-currency-total { text-align: right; font-weight: bold; color: #4338ca; background-color: #f1f5f9; mso-number-format:"\#\,\#\#0"; }

          .cell-grand-label { background-color: #e2e8f0; color: #0f172a; font-weight: bold; font-size: 10pt; border-top: 1.5pt solid #0f172a; border-bottom: 2pt double #0f172a; height: 26px; }
          .cell-grand-currency { text-align: right; background-color: #e2e8f0; color: #166534; font-weight: bold; font-size: 10pt; border-top: 1.5pt solid #0f172a; border-bottom: 2pt double #0f172a; mso-number-format:"\#\,\#\#0"; }
          .cell-grand-highlight { text-align: right; background-color: #dcfce7; color: #15803d; font-weight: bold; font-size: 11pt; border-top: 1.5pt solid #0f172a; border-bottom: 2pt double #0f172a; mso-number-format:"\#\,\#\#0"; }
        </style>
      </head>
      <body>
        ${tableContentHtml}
      </body>
    </html>
  `;

  const sanitizedTitle = title.replace(/[^a-zA-Z0-9_-]/g, '_');
  const fileName = `${sanitizedTitle}_${formatDateDDMMYYYY(new Date()).replace(/\//g, '-')}.xls`;
  downloadFileUniversal(excelTemplate, fileName, 'application/vnd.ms-excel;charset=utf-8;', title);
};

export const exportKumtluangMatrixToCSV = (
  transactions: Transaction[], 
  title: string = 'Kumtluang_Bawm_Category_Report',
  campaignName?: string,
  dateRangeText?: string,
  creatorInfo?: { name: string; orgName: string; phone: string; address?: string },
  sortOrder?: 'date-desc' | 'name-asc' | 'name-desc' | 'amount-desc',
  targetInfo?: TargetExportInfo
) => {
  const matrix = buildKumtluangMatrix(transactions, sortOrder);
  const orgDisplay = creatorInfo?.orgName?.trim() || (campaignName && campaignName !== 'All Campaigns' ? campaignName : '') || creatorInfo?.name?.trim() || 'RONPAY ORGANIZATION';
  const locationDisplay = creatorInfo?.address?.trim() || 'Mizoram, India';

  // Meta information headers with strict DD/MM/YYYY formatting and audit trail
  const metaRows = [
    `"${orgDisplay.toUpperCase()}"`,
    `"Location / Veng:","${locationDisplay.replace(/"/g, '""')}"`,
    `"Document:","Reports & Financial Statements"`,
    `"Trxn Date:","${(dateRangeText || 'All Dates').replace(/"/g, '""')}"`,
    `"Total Donors:","${matrix.rows.length}"`,
    `"⚡ Online Collection (UPI):","Rs. ${matrix.onlineTotal.toLocaleString('en-IN')}"`,
    `"💵 Cash Collection (Counter):","Rs. ${matrix.cashTotal.toLocaleString('en-IN')}"`,
    `"Grand Total Collection:","Rs. ${matrix.grandTotal.toLocaleString('en-IN')}"`,
    ...(targetInfo && targetInfo.targetAmount > 0 ? [
      `"🎯 Target Goal:","Rs. ${targetInfo.targetAmount.toLocaleString('en-IN')}${targetInfo.periodSuffix || ''} (${targetInfo.periodLabel || 'Target'})"`,
      `"📈 Target Achievement:","${targetInfo.progressPct ?? Math.round((matrix.grandTotal / targetInfo.targetAmount) * 100)}% Collected (Rs. ${matrix.grandTotal.toLocaleString('en-IN')} of Rs. ${targetInfo.targetAmount.toLocaleString('en-IN')})"`,
      `"Target Status:","${matrix.grandTotal >= targetInfo.targetAmount ? `Goal Achieved (+Rs. ${(matrix.grandTotal - targetInfo.targetAmount).toLocaleString('en-IN')} surplus)` : `Rs. ${(targetInfo.targetAmount - matrix.grandTotal).toLocaleString('en-IN')} la mamawh`}"`
    ] : []),
    `"Exported Date & Time:","${formatDateTimeDDMMYYYY(new Date().toISOString())}"`,
    `""`,
  ].filter(Boolean);

  // Headers: Hming, Payment Mode, Cat1, Cat2, ..., Total
  const headers = ['Hming (Donor)', 'Payment Mode', ...matrix.categories, 'Total (INR)'];

  const dataRows = matrix.rows.map(r => {
    return [
      `"${r.donorName.replace(/"/g, '""')}"`,
      `"${r.paymentMethodLabel}"`,
      ...matrix.categories.map(c => (r.categoryAmounts[c] || 0).toString()),
      r.total.toString(),
    ];
  });

  const totalRow = [
    '"TOTAL"',
    '""',
    ...matrix.categories.map(c => (matrix.columnTotals[c] || 0).toString()),
    matrix.grandTotal.toString(),
  ];

  const csvContent = [
    ...metaRows,
    headers.join(','),
    ...dataRows.map(row => row.join(',')),
    totalRow.join(','),
  ].join('\n');

  const sanitizedTitle = title.replace(/[^a-zA-Z0-9_-]/g, '_');
  const fileName = `${sanitizedTitle}_${formatDateDDMMYYYY(new Date()).replace(/\//g, '-')}.csv`;
  downloadFileUniversal(csvContent, fileName, 'text/csv;charset=utf-8;', title);
};

export const exportDetailedTransactionsCSV = (
  transactions: Transaction[],
  title: string = 'RonPay_Itemized_Transactions',
  campaignName?: string,
  dateRangeText?: string,
  creatorInfo?: { name: string; orgName: string; phone: string; address?: string },
  targetInfo?: TargetExportInfo
) => {
  const totalAmount = transactions.reduce((sum, t) => sum + t.amount, 0);
  const onlineTransactions = transactions.filter(t => t.paymentMethod === 'online');
  const cashTransactions = transactions.filter(t => t.paymentMethod === 'cash');
  const onlineTotal = onlineTransactions.reduce((sum, t) => sum + t.amount, 0);
  const cashTotal = cashTransactions.reduce((sum, t) => sum + t.amount, 0);

  const orgDisplay = creatorInfo?.orgName?.trim() || (campaignName && campaignName !== 'All Campaigns' ? campaignName : '') || creatorInfo?.name?.trim() || 'RONPAY ORGANIZATION';
  const locationDisplay = creatorInfo?.address?.trim() || 'Mizoram, India';

  // Meta info header with DD/MM/YYYY and audit details
  const metaRows = [
    `"${orgDisplay.toUpperCase()}"`,
    `"Location / Veng:","${locationDisplay.replace(/"/g, '""')}"`,
    `"Document:","Reports & Financial Statements"`,
    `"Trxn Date:","${(dateRangeText || 'All Dates').replace(/"/g, '""')}"`,
    `"Total Transactions:","${transactions.length}"`,
    `"⚡ Online Collection (UPI):","Rs. ${onlineTotal.toLocaleString('en-IN')} (${onlineTransactions.length} txns)"`,
    `"💵 Cash Collection (Counter):","Rs. ${cashTotal.toLocaleString('en-IN')} (${cashTransactions.length} txns)"`,
    `"Grand Total Collection:","Rs. ${totalAmount.toLocaleString('en-IN')}"`,
    ...(targetInfo && targetInfo.targetAmount > 0 ? [
      `"🎯 Target Goal:","Rs. ${targetInfo.targetAmount.toLocaleString('en-IN')}${targetInfo.periodSuffix || ''} (${targetInfo.periodLabel || 'Target'})"`,
      `"📈 Target Achievement:","${targetInfo.progressPct ?? Math.round((totalAmount / targetInfo.targetAmount) * 100)}% Collected (Rs. ${totalAmount.toLocaleString('en-IN')} of Rs. ${targetInfo.targetAmount.toLocaleString('en-IN')})"`,
      `"Target Status:","${totalAmount >= targetInfo.targetAmount ? `Goal Achieved (+Rs. ${(totalAmount - targetInfo.targetAmount).toLocaleString('en-IN')} surplus)` : `Rs. ${(targetInfo.targetAmount - totalAmount).toLocaleString('en-IN')} la mamawh`}"`
    ] : []),
    `"Exported Date & Time:","${formatDateTimeDDMMYYYY(new Date().toISOString())}"`,
    `""`,
  ].filter(Boolean);

  // Full headers including subcategory details
  const headers = [
    'Transaction ID',
    'Date & Time',
    'Category / Bawm',
    'Campaign Title',
    'Donor Name',
    'Amount (INR)',
    'Payment Mode',
    'Status',
    'Remarks / Note / Subcategory',
    'Reference / Tx Hash'
  ];

  const rows = transactions.map(t => {
    let breakdownStr = t.periodLabel || '';
    if (t.remark && t.remark.trim()) {
      breakdownStr = breakdownStr ? `${breakdownStr} | Note: ${t.remark.trim()}` : `Note: ${t.remark.trim()}`;
    }
    if (t.subCategoryBreakdown && Object.keys(t.subCategoryBreakdown).length > 0) {
      const parts = Object.entries(t.subCategoryBreakdown).map(([k, v]) => `${k}: Rs.${v}`);
      breakdownStr = breakdownStr ? `${breakdownStr} | ${parts.join('; ')}` : parts.join('; ');
    }

    return [
      `"${t.id}"`,
      `"${formatDateTimeDDMMYYYY(t.timestamp)}"`,
      `"${t.category.toUpperCase()}"`,
      `"${(t.campaignTitle || '').replace(/"/g, '""')}"`,
      `"${(t.isAnonymous ? 'Anonymous' : (t.donorName || '')).replace(/"/g, '""')}"`,
      t.amount.toFixed(2),
      `"${t.paymentMethod.toUpperCase()}"`,
      `"${t.status.toUpperCase()}"`,
      `"${breakdownStr.replace(/"/g, '""')}"`,
      `"${t.txHash || ''}"`
    ];
  });

  const totalRow = [
    '"TOTAL"',
    '""',
    '""',
    '""',
    `"${transactions.length} Transactions"`,
    totalAmount.toFixed(2),
    '""',
    '""',
    '""',
    '""'
  ];

  const csvContent = [
    ...metaRows,
    headers.join(','),
    ...rows.map(row => row.join(',')),
    totalRow.join(',')
  ].join('\n');

  const sanitizedTitle = title.replace(/[^a-zA-Z0-9_-]/g, '_');
  const fileName = `${sanitizedTitle}_${formatDateDDMMYYYY(new Date()).replace(/\//g, '-')}.csv`;
  downloadFileUniversal(csvContent, fileName, 'text/csv;charset=utf-8;', title);
};

export const exportTransactionsToCSV = (
  transactions: Transaction[], 
  title: string = 'RonPay_Transactions', 
  isKumtluang: boolean = false,
  campaignName?: string,
  dateRangeText?: string,
  creatorInfo?: { name: string; orgName: string; phone: string; address?: string },
  sortOrder?: 'date-desc' | 'name-asc' | 'name-desc' | 'amount-desc',
  targetInfo?: TargetExportInfo
) => {
  if (isKumtluang) {
    exportKumtluangMatrixToCSV(transactions, title, campaignName, dateRangeText, creatorInfo, sortOrder, targetInfo);
    return;
  }

  exportDetailedTransactionsCSV(transactions, title, campaignName, dateRangeText, creatorInfo, targetInfo);
};

/**
 * Generates the complete HTML string for the High-Precision PDF Financial Statement.
 */
export const generateTransactionsPDFHtml = (
  transactions: Transaction[], 
  title: string = 'Financial Statement', 
  isKumtluang: boolean = false,
  campaignName: string = 'All Campaigns',
  dateRangeText: string = 'All Time',
  imageUrl?: string,
  sortOrder?: 'date-desc' | 'name-asc' | 'name-desc' | 'amount-desc',
  creatorInfo?: { name: string; orgName: string; phone: string; address?: string },
  options: PDFExportOptions = { includeMonthlyChart: true, includeSignatures: true }
): string => {
  const totalAmount = transactions.reduce((sum, t) => sum + t.amount, 0);
  const onlineTransactions = transactions.filter(t => t.paymentMethod === 'online');
  const cashTransactions = transactions.filter(t => t.paymentMethod === 'cash');
  const onlineTotal = onlineTransactions.reduce((sum, t) => sum + t.amount, 0);
  const cashTotal = cashTransactions.reduce((sum, t) => sum + t.amount, 0);

  const rawOrg = creatorInfo?.orgName?.trim();
  const orgDisplay = (rawOrg && rawOrg !== 'RonPay HQ / Master Console') 
    ? rawOrg 
    : (campaignName && campaignName !== 'All Campaigns' ? campaignName : (creatorInfo?.name || 'NGO / Church / Organization'));
  const locationDisplay = creatorInfo?.address?.trim() || 'Mizoram, India';
  const creatorDisplay = creatorInfo ? `${creatorInfo.name} (${creatorInfo.phone || ''})` : 'Authorized Official';

  // Summary bar with breakdown of Online & Cash Collections
  const collectionSummaryBarHtml = `
    <div style="display: flex; gap: 10px; margin-bottom: 12px; flex-wrap: wrap; page-break-inside: avoid;">
      <div style="flex: 1; min-width: 150px; background: #eef2ff; border: 1px solid #c7d2fe; padding: 6px 12px; border-radius: 6px; display: flex; justify-content: space-between; align-items: center;">
        <div>
          <div style="font-size: 8.5px; font-weight: 800; color: #4338ca; text-transform: uppercase;">⚡ Online (UPI)</div>
          <div style="font-size: 13px; font-weight: 900; color: #1e1b4b;">₹${onlineTotal.toLocaleString('en-IN')}</div>
        </div>
        <span style="font-size: 9px; font-weight: bold; background: #c7d2fe; color: #312e81; padding: 2px 6px; border-radius: 4px;">${onlineTransactions.length} txns</span>
      </div>
      <div style="flex: 1; min-width: 150px; background: #fffbeb; border: 1px solid #fde68a; padding: 6px 12px; border-radius: 6px; display: flex; justify-content: space-between; align-items: center;">
        <div>
          <div style="font-size: 8.5px; font-weight: 800; color: #b45309; text-transform: uppercase;">💵 Cash (Counter)</div>
          <div style="font-size: 13px; font-weight: 900; color: #78350f;">₹${cashTotal.toLocaleString('en-IN')}</div>
        </div>
        <span style="font-size: 9px; font-weight: bold; background: #fde68a; color: #92400e; padding: 2px 6px; border-radius: 4px;">${cashTransactions.length} txns</span>
      </div>
      <div style="flex: 1.2; min-width: 180px; background: #f0fdf4; border: 1px solid #bbf7d0; padding: 6px 12px; border-radius: 6px; display: flex; justify-content: space-between; align-items: center;">
        <div>
          <div style="font-size: 8.5px; font-weight: 800; color: #15803d; text-transform: uppercase;">Grand Total Collection</div>
          <div style="font-size: 14px; font-weight: 900; color: #14532d;">₹${totalAmount.toLocaleString('en-IN')}</div>
        </div>
        <span style="font-size: 9px; font-weight: bold; background: #bbf7d0; color: #166534; padding: 2px 6px; border-radius: 4px;">${transactions.length} Total</span>
      </div>
    </div>
  `;

  // Target Progress bar and summary if target exists
  let targetSummaryHtml = '';
  if (options.targetInfo && options.targetInfo.targetAmount > 0) {
    const tInfo = options.targetInfo;
    const target = tInfo.targetAmount;
    const periodText = tInfo.periodSuffix || '';
    const pct = tInfo.progressPct ?? Math.round((totalAmount / target) * 100);
    const clampedPct = Math.min(pct, 100);
    const isDone = totalAmount >= target;
    const remaining = Math.max(0, target - totalAmount);
    const surplus = Math.max(0, totalAmount - target);

    targetSummaryHtml = `
      <div style="background: #f8fafc; border: 1.5px solid #818cf8; border-radius: 8px; padding: 8px 12px; margin-bottom: 14px; page-break-inside: avoid;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
          <div style="display: flex; align-items: center; gap: 6px;">
            <span style="font-size: 10.5px; font-weight: 900; color: #312e81; text-transform: uppercase; letter-spacing: 0.3px;">🎯 TARGET & COLLECTION PROGRESS</span>
            <span style="font-size: 8.5px; font-weight: bold; background: #e0e7ff; color: #3730a3; padding: 1px 6px; border-radius: 4px;">${tInfo.periodLabel || 'Target Goal'}</span>
          </div>
          <div style="font-size: 11px; font-weight: 900; color: ${isDone ? '#047857' : '#4338ca'};">
            ${pct}% Tling Tawh ${isDone ? '🎉 (Achieved)' : ''}
          </div>
        </div>
        
        <div style="display: flex; justify-content: space-between; font-size: 10px; margin-bottom: 5px; color: #334155;">
          <span>🎯 Target Goal: <b style="color: #0f172a;">₹${target.toLocaleString('en-IN')}${periodText}</b></span>
          <span>📈 Pek Tling Zat: <b style="color: #047857;">₹${totalAmount.toLocaleString('en-IN')}</b> (${pct}%)</span>
          <span>${isDone ? `🎉 A chuang: <b style="color: #047857;">+₹${surplus.toLocaleString('en-IN')}</b>` : `⏳ Mamawh Baki: <b style="color: #b45309;">₹${remaining.toLocaleString('en-IN')}</b>`}</span>
        </div>

        <div style="width: 100%; height: 7px; background: #e2e8f0; border-radius: 4px; overflow: hidden; border: 1px solid #cbd5e1;">
          <div style="width: ${clampedPct}%; height: 100%; background: ${isDone ? '#10b981' : '#4f46e5'}; border-radius: 3px;"></div>
        </div>
      </div>
    `;
  }

  // Build Monthly Chart HTML if requested
  let monthlyChartHtml = '';
  if (options.includeMonthlyChart !== false) {
    const { months, monthTotals, maxVal } = computeMonthlyDistribution(transactions, options.monthRangeConfig);
    
    const isSingleMonth = months.length === 1;
    const chartBars = months.map(m => {
      const val = monthTotals[m] || 0;
      // Calculate proportional height (min 6px, max 44px)
      const heightPx = val > 0 ? Math.max(12, Math.round((val / maxVal) * 44)) : 4;
      const isHigh = val > 0;
      const barWidth = isSingleMonth ? 28 : (months.length <= 3 ? 18 : 10);
      return `
        <div style="display: flex; flex-direction: column; align-items: center; justify-content: flex-end; height: 58px; flex: ${isSingleMonth ? '0 0 auto' : '1'}; min-width: 14px; padding: 0 4px;">
          <span style="font-size: 7px; color: #fef08a; margin-bottom: 2px; font-weight: bold;">₹${val > 999 ? (val/1000).toFixed(1) + 'k' : val}</span>
          <div style="width: ${barWidth}px; height: ${heightPx}px; background-color: ${isHigh ? '#ef4444' : '#334155'}; border: 1px solid ${isHigh ? '#f87171' : '#475569'}; border-radius: 3px 3px 0 0;"></div>
          <span style="font-size: 8px; color: ${isHigh ? '#fca5a5' : '#94a3b8'}; margin-top: 3px; font-weight: bold; text-transform: uppercase;">${m}</span>
        </div>
      `;
    }).join('');

    monthlyChartHtml = `
      <div class="chart-container" style="${isSingleMonth ? 'width: 140px;' : (months.length <= 4 ? 'width: 170px;' : 'width: 230px;')}">
        <div class="chart-title-box">
          <span class="chart-title">MONTHLY TREND</span>
        </div>
        <div class="chart-bars-wrap" style="${isSingleMonth ? 'justify-content: center;' : ''}">
          ${chartBars}
        </div>
      </div>
    `;
  }

  // Header Avatar Box HTML (Rounded with golden border)
  const avatarHtml = imageUrl 
    ? `<img src="${imageUrl}" class="header-avatar" alt="Logo" />`
    : `<div class="header-avatar-fallback">
        <svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z"/>
          <path d="M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2"/>
          <path d="M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2"/>
          <path d="M10 6h4"/><path d="M10 10h4"/><path d="M10 14h4"/><path d="M10 18h4"/>
        </svg>
      </div>`;

  // Signature Block HTML
  let signatureBlockHtml = '';
  if (options.includeSignatures !== false) {
    signatureBlockHtml = `
      <div class="sign-grid">
        <div class="sign-box">
          <div class="sign-label">${options.preparedByTitle || 'Prepared by (Recorder / Collector)'}</div>
          <div class="sign-subtext">${creatorDisplay}</div>
          <div class="digital-seal">✓ Digitally Verified by RonPay</div>
        </div>
        <div class="sign-box">
          <div class="sign-label">${options.verifiedByTitle || 'Verified by (Treasurer / Finance)'}</div>
          <div class="sign-subtext">Signature & Seal</div>
        </div>
        <div class="sign-box">
          <div class="sign-label">${options.approvedByTitle || 'Approved by (Secretary / Leader)'}</div>
          <div class="sign-subtext">Signature & Date</div>
        </div>
      </div>
    `;
  }

  // Common Print CSS Styles
  const sharedPrintStyles = `
    @page { 
      size: auto; 
      margin: 12mm 10mm 12mm 10mm; 
    }
    * { box-sizing: border-box; }
    body { 
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; 
      color: #1e293b; 
      margin: 0; 
      padding: 16px; 
      font-size: 11px; 
      background: #ffffff;
      -webkit-print-color-adjust: exact;
      print-color-adjust: exact;
    }
    
    /* Enhanced Top Header Banner (Only on first page) */
    .header-banner {
      background: linear-gradient(135deg, #090e1a 0%, #111827 50%, #1e1b4b 100%);
      border: 1.5px solid #312e81;
      border-radius: 18px;
      padding: 16px 20px;
      margin-bottom: 16px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 16px;
      box-shadow: 0 4px 14px rgba(0,0,0,0.15);
      page-break-after: avoid;
      break-after: avoid;
      page-break-inside: avoid;
      break-inside: avoid;
    }
    .header-left-wrap {
      display: flex;
      align-items: center;
      gap: 16px;
      min-width: 0;
      flex: 1;
    }
    .header-avatar {
      width: 84px;
      height: 84px;
      border-radius: 16px;
      object-fit: cover;
      border: 2.5px solid #f59e0b;
      box-shadow: 0 4px 10px rgba(0,0,0,0.4);
      flex-shrink: 0;
    }
    .header-avatar-fallback {
      width: 84px;
      height: 84px;
      border-radius: 16px;
      background-color: #1e293b;
      border: 2.5px solid #f59e0b;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }
    .header-content-stack {
      display: flex;
      flex-direction: column;
      gap: 2.5px;
      min-width: 0;
      flex: 1;
    }
    .org-title {
      font-size: 21px;
      font-weight: 900;
      color: #ffffff;
      letter-spacing: 0.3px;
      margin: 0;
      text-transform: uppercase;
      line-height: 1.2;
    }
    .location-text {
      font-size: 13px;
      font-weight: 700;
      color: #fbbf24;
      display: flex;
      align-items: center;
      gap: 4px;
      margin: 0;
      line-height: 1.25;
    }
    .doc-badge-title {
      font-size: 12px;
      font-weight: 800;
      color: #38bdf8;
      letter-spacing: 0.3px;
      text-transform: uppercase;
      margin: 0;
      line-height: 1.25;
    }
    .period-text {
      font-size: 11px;
      font-weight: 600;
      color: #cbd5e1;
      display: flex;
      align-items: center;
      gap: 4px;
      margin: 0;
      line-height: 1.25;
    }

    /* Right Chart Container */
    .chart-container {
      border: 1.5px solid #ef4444;
      border-radius: 12px;
      padding: 8px 12px;
      background: rgba(15, 23, 42, 0.7);
      width: 230px;
      flex-shrink: 0;
    }
    .chart-title-box {
      display: flex;
      flex-direction: column;
      border-bottom: 1px dashed rgba(239, 68, 68, 0.4);
      padding-bottom: 3px;
      margin-bottom: 6px;
    }
    .chart-title {
      font-size: 8.5px;
      font-weight: 900;
      color: #f87171;
      letter-spacing: 0.5px;
    }
    .chart-bars-wrap {
      display: flex;
      align-items: flex-end;
      gap: 3px;
      height: 58px;
      overflow-x: auto;
    }

    /* Table Styles */
    table { 
      width: 100% !important; 
      max-width: 100% !important;
      border-collapse: collapse; 
      text-align: left; 
      font-size: 11px; 
      margin-top: 8px; 
    }
    thead th {
      background: #1e1b4b;
      color: #ffffff;
      padding: 8px 10px;
      text-transform: uppercase;
      font-size: 9px;
      letter-spacing: 0.5px;
    }
    .total-row {
      background: #e2e8f0;
      font-weight: 900;
    }

    /* Prevent header row repeating on subsequent pages */
    thead {
      display: table-row-group !important;
    }
    tr {
      page-break-inside: avoid !important;
      break-inside: avoid !important;
    }
    tfoot {
      display: table-row-group !important;
    }

    /* Signature Blocks */
    .sign-grid {
      margin-top: 20px;
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 16px;
      text-align: center;
      page-break-inside: avoid !important;
      break-inside: avoid !important;
    }
    .sign-box {
      border-top: 1.5px dashed #64748b;
      padding-top: 6px;
    }
    .sign-label {
      font-size: 10.5px;
      font-weight: 800;
      color: #1e293b;
    }
    .sign-subtext {
      font-size: 9px;
      color: #64748b;
      margin-top: 2px;
    }
    .digital-seal {
      font-size: 8px;
      font-weight: bold;
      color: #4338ca;
      margin-top: 3px;
      display: inline-block;
      background: #e0e7ff;
      padding: 2px 6px;
      border-radius: 4px;
    }

    .footer {
      margin-top: 14px;
      border-top: 1px solid #cbd5e1;
      padding-top: 8px;
      font-size: 8.5px;
      color: #64748b;
      display: flex;
      justify-content: space-between;
      page-break-inside: avoid !important;
      break-inside: avoid !important;
    }

    @media screen and (max-width: 640px) {
      body { padding: 8px; font-size: 10px; }
      .header-banner { flex-direction: column; align-items: flex-start; padding: 12px; gap: 10px; }
      .header-avatar { width: 56px; height: 56px; }
      .chart-container { width: 100%; max-width: 100%; }
      .summary-bar { flex-direction: column; gap: 6px; }
      .target-bar { flex-direction: column; gap: 6px; }
      table { font-size: 10px; }
      th, td { padding: 6px 8px !important; }
      .sign-grid { grid-template-columns: 1fr; gap: 14px; margin-top: 18px; }
    }

    @media print {
      body { padding: 0; }
      .header-banner { margin-top: 0; }
      thead { display: table-row-group !important; }
    }
  `;

  // If Kumtluang Bawm, format matrix table: Sl No | Hming | Mode | Cat 1 | Cat 2 | ... | Total
  if (isKumtluang) {
    const matrix = buildKumtluangMatrix(transactions, sortOrder);
    const catCount = matrix.categories.length;
    // Multi-category matrix statements are wide ledgers - standard accounting format is A4 Landscape
    const isWideLedger = catCount >= 3;
    const pageOrientation = isWideLedger ? 'landscape' : 'portrait';

    const thPadding = catCount >= 6 ? '5px 4px' : catCount >= 4 ? '6px 6px' : '8px 10px';
    const thFontSize = catCount >= 6 ? '7.5px' : catCount >= 4 ? '8.5px' : '9.5px';
    const tdPadding = catCount >= 6 ? '5px 4px' : catCount >= 4 ? '6px 6px' : '7px 8px';
    const tdFontSize = catCount >= 6 ? '8.5px' : catCount >= 4 ? '9.5px' : '10px';

    const matrixHeaderThs = matrix.categories.map(c => `
      <th style="text-align: right; padding: ${thPadding}; font-weight: 800; font-size: ${thFontSize}; line-height: 1.15; word-break: break-word;">
        <div style="min-width: 55px;">${c.toUpperCase()}</div>
      </th>
    `).join('');
    
    const matrixRowsHtml = matrix.rows.map((r, idx) => {
      const modeBadge = r.paymentMethodLabel === 'CASH'
        ? `<span style="background: #fef3c7; color: #92400e; font-weight: bold; font-size: 8px; padding: 2px 5px; border-radius: 4px; border: 1px solid #fde68a;">💵 CASH</span>`
        : r.paymentMethodLabel === 'ONLINE'
        ? `<span style="background: #e0e7ff; color: #3730a3; font-weight: bold; font-size: 8px; padding: 2px 5px; border-radius: 4px; border: 1px solid #c7d2fe;">⚡ ONLINE</span>`
        : `<span style="background: #f1f5f9; color: #0f172a; font-weight: bold; font-size: 8px; padding: 2px 5px; border-radius: 4px; border: 1px solid #cbd5e1;">⚡+💵 MIXED</span>`;

      return `
      <tr style="background-color: ${idx % 2 === 0 ? '#ffffff' : '#f8fafc'};">
        <td style="padding: ${tdPadding}; border-bottom: 1px solid #e2e8f0; font-weight: 700; color: #64748b; text-align: center; width: 34px; font-size: ${tdFontSize};">${idx + 1}</td>
        <td style="padding: ${tdPadding}; border-bottom: 1px solid #e2e8f0; font-weight: 800; color: #0f172a; font-size: ${tdFontSize}; max-width: 170px; word-break: break-word;">${r.donorName}</td>
        <td style="padding: ${tdPadding}; border-bottom: 1px solid #e2e8f0; text-align: center; width: 66px;">${modeBadge}</td>
        ${matrix.categories.map(c => `
          <td style="padding: ${tdPadding}; border-bottom: 1px solid #e2e8f0; text-align: right; font-weight: 700; font-size: ${tdFontSize}; white-space: nowrap; color: ${r.categoryAmounts[c] > 0 ? '#0f172a' : '#94a3b8'};">
            ${r.categoryAmounts[c] > 0 ? `₹${r.categoryAmounts[c].toLocaleString('en-IN')}` : '-'}
          </td>
        `).join('')}
        <td style="padding: ${tdPadding}; border-bottom: 1px solid #e2e8f0; text-align: right; font-weight: 900; color: #4338ca; background-color: #f1f5f9; font-size: ${tdFontSize}; white-space: nowrap;">
          ₹${r.total.toLocaleString('en-IN')}
        </td>
      </tr>
    `;
    }).join('');

    const matrixFooterTds = matrix.categories.map(c => `
      <td style="text-align: right; padding: ${tdPadding}; font-weight: 900; color: #047857; border-top: 2px solid #0f172a; font-size: ${tdFontSize}; white-space: nowrap;">
        ₹${matrix.columnTotals[c].toLocaleString('en-IN')}
      </td>
    `).join('');

    const orientationStyle = isWideLedger ? `
      @page { size: A4 landscape; margin: 8mm; }
    ` : `
      @page { size: A4 portrait; margin: 10mm; }
    `;

    return `
      <!DOCTYPE html>
      <html>
        <head>
          <title>${orgDisplay} - Financial Statement</title>
          <meta charset="utf-8" />
          <meta name="viewport" content="width=device-width, initial-scale=1" />
          <meta name="x-report-orientation" content="${pageOrientation}" />
          <style>
            ${sharedPrintStyles}
            ${orientationStyle}
          </style>
        </head>
        <body data-default-orientation="${pageOrientation}" class="report-orientation-${pageOrientation}">
          <div class="header-banner">
            <div class="header-left-wrap">
              ${avatarHtml}
              <div class="header-content-stack">
                <h1 class="org-title">${orgDisplay}</h1>
                <div class="location-text">📍 ${locationDisplay}</div>
                <div class="doc-badge-title">Reports & Financial Statements</div>
                <div class="period-text">Trxn Date: <b>${dateRangeText}</b></div>
              </div>
            </div>
            ${monthlyChartHtml}
          </div>

          ${collectionSummaryBarHtml}
          ${targetSummaryHtml}

          <div style="width: 100%; overflow-x: visible;">
            <table style="width: 100%; max-width: 100%; border-collapse: collapse; table-layout: auto;">
              <thead>
                <tr>
                  <th style="width: 34px; text-align: center; padding: ${thPadding}; font-size: ${thFontSize};">SL NO.</th>
                  <th style="padding: ${thPadding}; font-size: ${thFontSize};">HMING (DONOR)</th>
                  <th style="width: 66px; text-align: center; padding: ${thPadding}; font-size: ${thFontSize};">MODE</th>
                  ${matrixHeaderThs}
                  <th style="text-align: right; padding: ${thPadding}; background: #312e81; font-size: ${thFontSize}; white-space: nowrap;">TOTAL (₹)</th>
                </tr>
              </thead>
              <tbody>
                ${matrixRowsHtml}
              </tbody>
              <tfoot>
                <tr class="total-row">
                  <td colspan="3" style="padding: ${tdPadding}; font-weight: 900; color: #1e1b4b; border-top: 2px solid #0f172a; font-size: ${tdFontSize};">GRAND TOTAL</td>
                  ${matrixFooterTds}
                  <td style="text-align: right; padding: ${tdPadding}; font-weight: 900; color: #047857; border-top: 2px solid #0f172a; font-size: ${tdFontSize}; background-color: #dcfce7; white-space: nowrap;">
                    ₹${matrix.grandTotal.toLocaleString('en-IN')}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>

          ${signatureBlockHtml}

          <div class="footer">
            <span>${orgDisplay} • Official Financial Statement</span>
            <span>Generated Date: ${formatDateDDMMYYYY(new Date())}</span>
          </div>
        </body>
      </html>
    `;
  }

  // Standard report (Grouped by Donor by default, or Itemized if unselected)
  const shouldGroupByDonor = options.groupByDonor !== false;
  const showDateTime = options.showDateTime !== false;

  let tableHeaderHtml = '';
  let rowsHtml = '';
  let tableFooterColspan = 4;

  if (shouldGroupByDonor) {
    const groupedRecords = buildGroupedDonorRecords(transactions, sortOrder);
    tableFooterColspan = showDateTime ? 5 : 4;

    tableHeaderHtml = `
      <tr>
        <th style="width: 45px; text-align: center;">SL NO.</th>
        <th style="padding: 10px 12px;">HMING (DONOR)</th>
        <th style="width: 95px; text-align: center;">PAYMENT MODE</th>
        ${showDateTime ? '<th style="padding: 10px 12px;">DATE / THLA BI</th>' : ''}
        <th style="padding: 10px 12px;">PEK ZAT / DETAILS</th>
        <th style="padding: 10px 12px;">REMARKS / NOTE</th>
        <th style="text-align: right; padding: 10px 12px;">TOTAL AMOUNT (₹)</th>
      </tr>
    `;

    rowsHtml = groupedRecords.map((d, idx) => {
      const modeBadge = d.paymentMethodLabel === 'CASH'
        ? `<span style="background: #fef3c7; color: #92400e; font-weight: bold; font-size: 8.5px; padding: 2px 6px; border-radius: 4px; border: 1px solid #fde68a;">💵 CASH</span>`
        : d.paymentMethodLabel === 'ONLINE'
        ? `<span style="background: #e0e7ff; color: #3730a3; font-weight: bold; font-size: 8.5px; padding: 2px 6px; border-radius: 4px; border: 1px solid #c7d2fe;">⚡ ONLINE</span>`
        : `<span style="background: #f1f5f9; color: #0f172a; font-weight: bold; font-size: 8.5px; padding: 2px 6px; border-radius: 4px; border: 1px solid #cbd5e1;">⚡+💵 MIXED</span>`;

      const memberBadge = d.memberId ? `<span style="font-family: monospace; font-size: 9px; background: #e2e8f0; color: #334155; padding: 1px 4px; border-radius: 3px; margin-left: 6px;">${d.memberId}</span>` : '';
      const sectionInfo = d.section ? `<span style="font-size: 9.5px; color: #64748b; margin-left: 4px;">• ${d.section}</span>` : '';
      
      const countLabel = d.transactionsCount > 1 
        ? `<span style="font-weight: 700; color: #1e293b;">${d.transactionsCount} payments</span>` 
        : `<span style="color: #64748b;">1 payment</span>`;

      const breakdownParts = Object.entries(d.categoryBreakdown).map(([k, v]) => `${k}: ₹${v.toLocaleString('en-IN')}`);
      const breakdownText = breakdownParts.length > 1 ? `<div style="font-size: 9px; color: #64748b; margin-top: 2px;">${breakdownParts.join(', ')}</div>` : '';

      const dateOrMonths = d.dateRange || d.monthsPaid.join(', ') || '-';
      const remarksText = d.remarks.length > 0 ? d.remarks.join(' • ') : '-';

      return `
        <tr style="background-color: ${idx % 2 === 0 ? '#ffffff' : '#f8fafc'};">
          <td style="padding: 8px 10px; border-bottom: 1px solid #e2e8f0; font-weight: 700; color: #64748b; text-align: center; width: 45px;">${idx + 1}</td>
          <td style="padding: 8px 10px; border-bottom: 1px solid #e2e8f0; font-weight: bold; font-size: 11px; color: #0f172a;">
            ${d.isAnonymous ? '<i>Anonymous</i>' : d.donorName}
            ${memberBadge}
            ${sectionInfo}
          </td>
          <td style="padding: 8px 10px; border-bottom: 1px solid #e2e8f0; font-size: 10px; text-align: center;">${modeBadge}</td>
          ${showDateTime ? `<td style="padding: 8px 10px; border-bottom: 1px solid #e2e8f0; font-size: 10px; color: #475569;">${dateOrMonths}</td>` : ''}
          <td style="padding: 8px 10px; border-bottom: 1px solid #e2e8f0; font-size: 10.5px; color: #334155;">
            ${countLabel}
            ${breakdownText}
          </td>
          <td style="padding: 8px 10px; border-bottom: 1px solid #e2e8f0; font-size: 10px; color: #64748b;">${remarksText}</td>
          <td style="padding: 8px 10px; border-bottom: 1px solid #e2e8f0; text-align: right; font-weight: 800; font-size: 11.5px; color: #0f172a; background-color: ${idx % 2 === 0 ? '#f8fafc' : '#f1f5f9'};">
            ₹${d.totalAmount.toLocaleString('en-IN')}
          </td>
        </tr>
      `;
    }).join('');
  } else {
    // Itemized line by line view
    tableFooterColspan = showDateTime ? 5 : 4;
    tableHeaderHtml = `
      <tr>
        <th style="width: 45px; text-align: center;">SL NO.</th>
        ${showDateTime ? '<th style="padding: 10px 12px;">DATE & TIME</th>' : ''}
        <th style="padding: 10px 12px;">HMING (DONOR)</th>
        <th style="width: 85px; text-align: center;">MODE</th>
        <th style="padding: 10px 12px;">REMARKS / NOTE</th>
        <th style="padding: 10px 12px;">TXN REF</th>
        <th style="text-align: right; padding: 10px 12px;">AMOUNT (₹)</th>
      </tr>
    `;

    rowsHtml = transactions.map((t, idx) => {
      const isCash = t.paymentMethod.toLowerCase().includes('cash');
      const paymentBadge = isCash
        ? `<span style="background: #fef3c7; color: #92400e; font-weight: bold; font-size: 9px; padding: 2px 6px; border-radius: 4px; border: 1px solid #fde68a;">💵 CASH</span>`
        : `<span style="background: #e0e7ff; color: #3730a3; font-weight: bold; font-size: 9px; padding: 2px 6px; border-radius: 4px; border: 1px solid #c7d2fe;">⚡ ONLINE</span>`;

      let remarks = t.periodLabel || '';
      if (t.remark && t.remark.trim()) {
        remarks = remarks ? `${remarks} • Note: ${t.remark.trim()}` : t.remark.trim();
      }
      if (t.subCategoryBreakdown && Object.keys(t.subCategoryBreakdown).length > 0) {
        const parts = Object.entries(t.subCategoryBreakdown).map(([k, v]) => `${k}: ₹${v}`);
        remarks = remarks ? `${remarks} (${parts.join(', ')})` : parts.join(', ');
      }

      return `
        <tr style="background-color: ${idx % 2 === 0 ? '#ffffff' : '#f8fafc'};">
          <td style="padding: 8px 10px; border-bottom: 1px solid #e2e8f0; font-weight: 700; color: #64748b; text-align: center; width: 45px;">${idx + 1}</td>
          ${showDateTime ? `<td style="padding: 8px 10px; border-bottom: 1px solid #e2e8f0; font-size: 10px; font-family: monospace;">${formatDateTimeDDMMYYYY(t.timestamp)}</td>` : ''}
          <td style="padding: 8px 10px; border-bottom: 1px solid #e2e8f0; font-weight: bold; font-size: 11px; color: #0f172a;">${t.isAnonymous ? '<i>Anonymous</i>' : t.donorName}</td>
          <td style="padding: 8px 10px; border-bottom: 1px solid #e2e8f0; font-size: 10px; text-align: center;">${paymentBadge}</td>
          <td style="padding: 8px 10px; border-bottom: 1px solid #e2e8f0; font-size: 10.5px; color: #334155;">${remarks || '-'}</td>
          <td style="padding: 8px 10px; border-bottom: 1px solid #e2e8f0; font-family: monospace; font-size: 9.5px; color: #64748b;">${t.txHash || t.id.slice(0, 12)}</td>
          <td style="padding: 8px 10px; border-bottom: 1px solid #e2e8f0; text-align: right; font-weight: 800; font-size: 11px; color: #0f172a;">₹${t.amount.toLocaleString('en-IN')}</td>
        </tr>
      `;
    }).join('');
  }

  return `
    <!DOCTYPE html>
    <html>
      <head>
        <title>${orgDisplay} - Financial Statement</title>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="x-report-orientation" content="portrait" />
        <style>
          ${sharedPrintStyles}
          @page { size: A4 portrait; margin: 10mm; }
        </style>
      </head>
      <body data-default-orientation="portrait" class="report-orientation-portrait">
        <div class="header-banner">
          <div class="header-left-wrap">
            ${avatarHtml}
            <div class="header-content-stack">
              <h1 class="org-title">${orgDisplay}</h1>
              <div class="location-text">📍 ${locationDisplay}</div>
              <div class="doc-badge-title">Reports & Financial Statements</div>
              <div class="period-text">Trxn Date: <b>${dateRangeText}</b></div>
            </div>
          </div>
          ${monthlyChartHtml}
        </div>

        ${collectionSummaryBarHtml}
        ${targetSummaryHtml}

        <table>
          <thead>
            ${tableHeaderHtml}
          </thead>
          <tbody>
            ${rowsHtml}
          </tbody>
          <tfoot>
            <tr style="background: #e2e8f0; font-weight: 900;">
              <td colspan="${tableFooterColspan + 1}" style="padding: 11px 12px; border-top: 2px solid #0f172a; font-size: 12px; color: #1e1b4b;">GRAND TOTAL COLLECTION</td>
              <td style="padding: 11px 12px; border-top: 2px solid #0f172a; text-align: right; font-size: 13px; color: #047857; background: #dcfce7;">
                ₹${totalAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
              </td>
            </tr>
          </tfoot>
        </table>

        ${signatureBlockHtml}

        <div class="footer">
          <span>${orgDisplay} • Official Financial Statement</span>
          <span>Generated Date: ${formatDateDDMMYYYY(new Date())}</span>
        </div>
      </body>
    </html>
  `;
};

/**
 * Generates and prints the High-Precision PDF Financial Statement.
 */
export const printTransactionsPDF = (
  transactions: Transaction[], 
  title: string = 'Financial Statement', 
  isKumtluang: boolean = false,
  campaignName: string = 'All Campaigns',
  dateRangeText: string = 'All Time',
  imageUrl?: string,
  sortOrder?: 'date-desc' | 'name-asc' | 'name-desc' | 'amount-desc',
  creatorInfo?: { name: string; orgName: string; phone: string; address?: string },
  options: PDFExportOptions = { includeMonthlyChart: true, includeSignatures: true }
) => {
  const html = generateTransactionsPDFHtml(
    transactions,
    title,
    isKumtluang,
    campaignName,
    dateRangeText,
    imageUrl,
    sortOrder,
    creatorInfo,
    options
  );
  printHtmlSafely(html, `${campaignName} - ${title}`);
};

/**
 * Helper to determine if a transaction belongs to a specific Member Record.
 * Matches by:
 * 1. Direct memberId match
 * 2. Remark containing member.id
 * 3. Phone number matching (exact or last 4 digits)
 * 4. Fuzzy name matching (handling accents, punctuation, '& Chhungte', etc.)
 */
export const isTransactionForMember = (t: Transaction, member: MemberRecord): boolean => {
  if (!t || !member) return false;

  // Strict Org / Campaign Guard: Prevent cross-campaign contamination (e.g. EBE vs KTL)
  if (t.memberId && member.orgCode) {
    const tPrefix = t.memberId.split('-')[0].toUpperCase();
    const mPrefix = member.orgCode.toUpperCase();
    if (tPrefix && mPrefix && tPrefix !== mPrefix) {
      return false;
    }
  }
  if (t.campaignId && member.campaignId && t.campaignId !== member.campaignId) {
    return false;
  }

  // 1. Direct member ID match
  if (t.memberId && member.id && t.memberId.toLowerCase().trim() === member.id.toLowerCase().trim()) {
    return true;
  }

  // 2. Remark containing Member ID
  if (t.remark && member.id && t.remark.toLowerCase().includes(member.id.toLowerCase().trim())) {
    return true;
  }

  // 3. Phone number match (last 4 digits or full phone)
  if (t.donorPhone && (member.fullPhone || member.phoneLast4)) {
    const cleanTxPhone = t.donorPhone.replace(/\D/g, '');
    const cleanMemPhone = (member.fullPhone || '').replace(/\D/g, '');
    if (cleanTxPhone && cleanMemPhone && cleanTxPhone === cleanMemPhone) {
      return true;
    }
    if (cleanTxPhone.length >= 4 && member.phoneLast4 && cleanTxPhone.endsWith(member.phoneLast4)) {
      return true;
    }
  }

  // 4. Robust Name Match
  if (t.donorName && member.name) {
    const tClean = t.donorName.toLowerCase().replace(/[^a-z0-9]/g, '');
    const mClean = member.name.toLowerCase().replace(/[^a-z0-9]/g, '');
    if (tClean === mClean) return true;
    if (tClean.length > 3 && mClean.length > 3) {
      if (tClean.includes(mClean) || mClean.includes(tClean)) return true;
    }

    // Check primary name without '& Chhungte' / '(Nupui)'
    const tPrimary = t.donorName.split('&')[0].replace(/\([^)]*\)/g, '').trim().toLowerCase();
    const mPrimary = member.name.split('&')[0].replace(/\([^)]*\)/g, '').trim().toLowerCase();
    if (tPrimary && mPrimary && (tPrimary === mPrimary || tPrimary.includes(mPrimary) || mPrimary.includes(tPrimary))) {
      return true;
    }
  }

  return false;
};

/**
 * Extracts category contribution amount from a transaction.
 * Supports subCategoryBreakdown object and direct subCategory/remark matching.
 */
export const getTransactionCategoryAmount = (t: Transaction, category: string): number => {
  if (!t || !category) return 0;
  const targetCatLower = category.toLowerCase().trim();

  // If transaction has detailed multi-category breakdown
  if (t.subCategoryBreakdown && typeof t.subCategoryBreakdown === 'object') {
    // 1. Exact key match
    for (const [key, val] of Object.entries(t.subCategoryBreakdown)) {
      if (key.toLowerCase().trim() === targetCatLower) {
        return Number(val) || 0;
      }
    }
    // 2. Partial key match
    for (const [key, val] of Object.entries(t.subCategoryBreakdown)) {
      const kLower = key.toLowerCase().trim();
      if (kLower.includes(targetCatLower) || targetCatLower.includes(kLower)) {
        return Number(val) || 0;
      }
    }
  }

  // Fallback to single subCategory matching
  if (t.subCategory) {
    const subLower = t.subCategory.toLowerCase().trim();
    if (subLower === targetCatLower || subLower.includes(targetCatLower) || targetCatLower.includes(subLower)) {
      return t.amount || 0;
    }
  }

  // Fallback to remark matching
  if (t.remark) {
    const remarkLower = t.remark.toLowerCase();
    if (remarkLower.includes(targetCatLower)) {
      return t.amount || 0;
    }
  }

  return 0;
};

/**
 * Format 1: Master 12-Month Table HTML Generator
 */
export const generateMasterLedgerPrintHtml = (
  members: MemberRecord[],
  transactions: Transaction[],
  campaignTitle: string,
  orgName: string,
  logoUrl?: string,
  location?: string
): string => {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const monthTotals: { [key: string]: number } = {};
  months.forEach(m => { monthTotals[m] = 0; });
  let grandTotal = 0;

  const rowsHtml = members.map((member, idx) => {
    const memberTxns = transactions.filter(t => isTransactionForMember(t, member));

    let rowTotal = 0;
    const monthCols = months.map(m => {
      const monthTxns = memberTxns.filter(t => isTransactionInMonth(t, m));
      const sum = monthTxns.reduce((acc, t) => acc + (t.amount || 0), 0);
      rowTotal += sum;
      monthTotals[m] += sum;
      return `<td style="text-align: right; padding: 6px 8px; border: 1px solid #cbd5e1; font-family: monospace; font-size: 11px;">${sum > 0 ? sum.toLocaleString('en-IN') : '-'}</td>`;
    }).join('');

    grandTotal += rowTotal;

    const avatarThumbnail = member.avatarUrl
      ? `<img src="${member.avatarUrl}" style="width: 22px; height: 22px; border-radius: 50%; object-fit: cover; vertical-align: middle; margin-right: 6px; border: 1px solid #cbd5e1;" />`
      : '';

    return `
      <tr style="background: ${idx % 2 === 0 ? '#ffffff' : '#f8fafc'};">
        <td style="padding: 6px 8px; border: 1px solid #cbd5e1; font-weight: bold; text-align: center; font-size: 11px; color: #64748b;">${idx + 1}</td>
        <td style="padding: 6px 8px; border: 1px solid #cbd5e1; font-weight: 900; font-family: monospace; color: #1e3a8a; font-size: 11px;">${member.id}</td>
        <td style="padding: 6px 8px; border: 1px solid #cbd5e1; font-weight: bold; font-size: 11px; color: #0f172a;">${avatarThumbnail}${member.name}</td>
        <td style="padding: 6px 8px; border: 1px solid #cbd5e1; color: #64748b; font-size: 10px;">${member.section || '-'}</td>
        ${monthCols}
        <td style="text-align: right; padding: 6px 8px; border: 1px solid #cbd5e1; font-weight: 900; background: #e0f2fe; color: #0369a1; font-family: monospace; font-size: 11px;">
          ${rowTotal > 0 ? rowTotal.toLocaleString('en-IN') : '-'}
        </td>
      </tr>
    `;
  }).join('');

  const monthTotalCols = months.map(m => `
    <td style="text-align: right; padding: 8px; border: 1px solid #0f172a; font-weight: 900; font-family: monospace; font-size: 11px;">
      ${monthTotals[m] > 0 ? monthTotals[m].toLocaleString('en-IN') : '-'}
    </td>
  `).join('');

  const logoHeader = logoUrl 
    ? `<img src="${logoUrl}" style="width: 52px; height: 52px; border-radius: 10px; object-fit: cover; border: 1.5px solid #1e3a8a; margin-right: 12px;" />`
    : '';

  return `
    <!DOCTYPE html>
    <html>
      <head>
        <title>Master Ledger • ${orgName}</title>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <style>
          @page { size: A4 landscape; margin: 8mm; }
          body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; color: #0f172a; margin: 0; padding: 0; }
          table { width: 100%; border-collapse: collapse; margin-top: 10px; }
          th { background: #1e293b; color: white; padding: 8px 6px; font-size: 10px; text-transform: uppercase; border: 1px solid #0f172a; }
          .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #1e3a8a; padding-bottom: 8px; }
          .header-left { display: flex; align-items: center; }
          @media print {
            thead { display: table-row-group !important; }
            tr { page-break-inside: avoid !important; break-inside: avoid !important; }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="header-left">
            ${logoHeader}
            <div>
              <h1 style="margin: 0; font-size: 18px; color: #1e3a8a; font-weight: 900; text-transform: uppercase;">${orgName}</h1>
              <h2 style="margin: 2px 0 0 0; font-size: 12.5px; color: #475569;">${campaignTitle} — Master Ledger 12 Months</h2>
              ${location ? `<div style="font-size: 10px; color: #b45309; font-weight: 700; margin-top: 2px;">📍 ${location}</div>` : ''}
            </div>
          </div>
          <div style="text-align: right; font-size: 10px; color: #64748b;">
            <div>Printed Date: <b>${formatDateDDMMYYYY(new Date())}</b></div>
            <div>Total Active Members: <b>${members.length}</b></div>
            <div style="color: #047857; font-weight: 900; margin-top: 2px;">Grand Total: ₹${grandTotal.toLocaleString('en-IN')}</div>
          </div>
        </div>

        <table>
          <thead>
            <tr>
              <th style="width: 30px;">#</th>
              <th style="width: 75px;">ID</th>
              <th>NAME</th>
              <th>SEC</th>
              ${months.map(m => `<th style="width: 45px;">${m.toUpperCase()}</th>`).join('')}
              <th style="width: 65px; background: #0284c7;">TOTAL</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml}
          </tbody>
          <tfoot>
            <tr style="background: #e2e8f0; font-weight: 900;">
              <td colspan="4" style="padding: 8px; border: 1px solid #0f172a; text-align: right; font-size: 11px; color: #0f172a;">
                G TOTAL (GRAND TOTAL):
              </td>
              ${monthTotalCols}
              <td style="text-align: right; padding: 8px; border: 1px solid #0f172a; font-weight: 900; background: #0284c7; color: white; font-family: monospace; font-size: 12px;">
                ₹${grandTotal.toLocaleString('en-IN')}
              </td>
            </tr>
          </tfoot>
        </table>
      </body>
    </html>
  `;
};

export const exportMasterLedgerPrint = (
  members: MemberRecord[],
  transactions: Transaction[],
  campaignTitle: string,
  orgName: string,
  logoUrl?: string,
  location?: string
) => {
  const html = generateMasterLedgerPrintHtml(members, transactions, campaignTitle, orgName, logoUrl, location);
  printHtmlSafely(html, `Master Ledger • ${orgName}`);
};

/**
 * Format 2: Member Category Matrix HTML Generator (Horizontal)
 * Displays Member Photo if uploaded, or clean Initials / Blank card if not.
 */
export const generateMemberCategoryMatrixPrintHtml = (
  member: MemberRecord,
  categories: string[],
  transactions: Transaction[],
  orgName: string,
  logoUrl?: string,
  location?: string
): string => {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const memberTxns = transactions.filter(t => isTransactionForMember(t, member));

  const monthTotals: { [key: string]: number } = {};
  months.forEach(m => { monthTotals[m] = 0; });
  let grandTotal = 0;

  const rowsHtml = categories.map((cat, idx) => {
    let rowTotal = 0;
    const monthCols = months.map(m => {
      const monthTxns = memberTxns.filter(t => isTransactionInMonth(t, m));
      const sum = monthTxns.reduce((acc, t) => acc + getTransactionCategoryAmount(t, cat), 0);
      rowTotal += sum;
      monthTotals[m] += sum;
      return `<td style="text-align: right; padding: 8px; border: 1px solid #cbd5e1; font-family: monospace; font-size: 11px;">${sum > 0 ? sum.toLocaleString('en-IN') : '-'}</td>`;
    }).join('');

    grandTotal += rowTotal;

    return `
      <tr style="background: ${idx % 2 === 0 ? '#ffffff' : '#f8fafc'};">
        <td style="padding: 8px; border: 1px solid #cbd5e1; font-weight: bold; text-align: center; font-size: 11px;">${idx + 1}</td>
        <td style="padding: 8px; border: 1px solid #cbd5e1; font-weight: bold; font-size: 11px; color: #1e3a8a;">${cat}</td>
        ${monthCols}
        <td style="text-align: right; padding: 8px; border: 1px solid #cbd5e1; font-weight: 900; background: #e0f2fe; color: #0369a1; font-family: monospace; font-size: 11px;">
          ${rowTotal > 0 ? rowTotal.toLocaleString('en-IN') : '-'}
        </td>
      </tr>
    `;
  }).join('');

  // Member photo vs blank initials
  const memberPhotoHtml = member.avatarUrl 
    ? `<img src="${member.avatarUrl}" style="width: 72px; height: 72px; border-radius: 12px; object-fit: cover; border: 2px solid #1e3a8a; flex-shrink: 0; box-shadow: 0 2px 6px rgba(0,0,0,0.1);" />`
    : `<div style="width: 72px; height: 72px; border-radius: 12px; background: #e2e8f0; border: 1.5px dashed #94a3b8; display: flex; align-items: center; justify-content: center; color: #64748b; font-weight: 900; font-size: 20px; flex-shrink: 0;">${member.name.charAt(0) || 'M'}</div>`;

  const orgLogoHtml = logoUrl 
    ? `<img src="${logoUrl}" style="width: 36px; height: 36px; border-radius: 6px; object-fit: cover; vertical-align: middle; margin-right: 6px; border: 1px solid #cbd5e1;" />`
    : '';

  return `
    <!DOCTYPE html>
    <html>
      <head>
        <title>Mimal Record • ${member.name} (${member.id})</title>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <style>
          @page { size: A4 landscape; margin: 10mm; }
          body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; color: #0f172a; }
          table { width: 100%; border-collapse: collapse; margin-top: 12px; }
          th { background: #1e293b; color: white; padding: 8px; font-size: 10.5px; text-transform: uppercase; border: 1px solid #0f172a; }
          .card { border: 1.5px solid #1e3a8a; border-radius: 12px; padding: 12px 16px; margin-bottom: 12px; background: #f8fafc; }
          @media print {
            thead { display: table-row-group !important; }
            tr { page-break-inside: avoid !important; break-inside: avoid !important; }
          }
        </style>
      </head>
      <body>
        <div class="card">
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <div style="display: flex; align-items: center; gap: 14px;">
              ${memberPhotoHtml}
              <div>
                <div style="font-size: 10.5px; color: #475569; font-weight: bold; text-transform: uppercase; display: flex; align-items: center;">
                  ${orgLogoHtml} ${orgName} ${location ? `• 📍 ${location}` : ''}
                </div>
                <h1 style="margin: 2px 0 0 0; font-size: 20px; color: #1e3a8a; font-weight: 900;">${member.name}</h1>
                <div style="font-size: 11.5px; color: #334155; margin-top: 2px;">
                  Section: <b>${member.section || 'N/A'}</b> • Phone: <b>${member.fullPhone || `****${member.phoneLast4}`}</b>
                  ${member.dependents && member.dependents.length > 0 ? ` • Dependents: <b>${member.dependents.map(d => `${d.name} (${d.relation})`).join(', ')}</b>` : ''}
                </div>
              </div>
            </div>
            <div style="text-align: right;">
              <div style="font-size: 9.5px; color: #64748b; font-weight: bold; text-transform: uppercase;">UNIQUE MEMBER ID</div>
              <div style="font-size: 16px; font-weight: 900; font-family: monospace; color: #047857; background: #dcfce7; padding: 4px 10px; border-radius: 6px; border: 1px solid #86efac; margin-top: 3px;">${member.id}</div>
              <div style="font-size: 10px; color: #64748b; margin-top: 4px;">Statement Date: ${formatDateDDMMYYYY(new Date())}</div>
            </div>
          </div>
        </div>

        <table>
          <thead>
            <tr>
              <th style="width: 30px;">#</th>
              <th>HEAD / CATEGORY</th>
              ${months.map(m => `<th style="width: 48px;">${m.toUpperCase()}</th>`).join('')}
              <th style="width: 70px; background: #0284c7;">TOTAL</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml}
          </tbody>
          <tfoot>
            <tr style="background: #e2e8f0; font-weight: 900;">
              <td colspan="2" style="padding: 8px; border: 1px solid #0f172a; text-align: right; font-size: 11px;">G TOTAL:</td>
              ${months.map(m => `
                <td style="text-align: right; padding: 8px; border: 1px solid #0f172a; font-family: monospace; font-size: 11px;">
                  ${monthTotals[m] > 0 ? monthTotals[m].toLocaleString('en-IN') : '-'}
                </td>
              `).join('')}
              <td style="text-align: right; padding: 8px; border: 1px solid #0f172a; font-weight: 900; background: #0284c7; color: white; font-family: monospace; font-size: 12px;">
                ₹${grandTotal.toLocaleString('en-IN')}
              </td>
            </tr>
          </tfoot>
        </table>
      </body>
    </html>
  `;
};

export const exportMemberCategoryMatrixPrint = (
  member: MemberRecord,
  categories: string[],
  transactions: Transaction[],
  orgName: string,
  logoUrl?: string,
  location?: string
) => {
  const html = generateMemberCategoryMatrixPrintHtml(member, categories, transactions, orgName, logoUrl, location);
  printHtmlSafely(html, `Mimal Record • ${member.name} (${member.id})`);
};

/**
 * Format 3: Member Passbook Vertical Card HTML Generator
 * Displays Member Photo if uploaded, or clean Initials / Blank card if not.
 */
export const generateMemberPassbookVerticalPrintHtml = (
  member: MemberRecord,
  categories: string[],
  transactions: Transaction[],
  orgName: string,
  logoUrl?: string,
  location?: string
): string => {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const memberTxns = transactions.filter(t => isTransactionForMember(t, member));

  let grandTotal = 0;
  const categoryTotals: { [cat: string]: number } = {};
  categories.forEach(c => { categoryTotals[c] = 0; });

  const rowsHtml = months.map((month, idx) => {
    let monthTotal = 0;
    const monthTxns = memberTxns.filter(t => isTransactionInMonth(t, month));

    const catCols = categories.map(cat => {
      const sum = monthTxns.reduce((acc, t) => acc + getTransactionCategoryAmount(t, cat), 0);
      monthTotal += sum;
      categoryTotals[cat] += sum;
      return `<td style="text-align: right; padding: 7px 8px; border: 1px solid #cbd5e1; font-family: monospace; font-size: 11px;">${sum > 0 ? sum.toLocaleString('en-IN') : '-'}</td>`;
    }).join('');

    grandTotal += monthTotal;

    return `
      <tr style="background: ${idx % 2 === 0 ? '#ffffff' : '#f8fafc'};">
        <td style="padding: 7px 8px; border: 1px solid #cbd5e1; font-weight: bold; text-align: center; font-size: 11px;">${idx + 1}</td>
        <td style="padding: 7px 8px; border: 1px solid #cbd5e1; font-weight: bold; font-size: 11px; color: #1e3a8a;">${month}</td>
        ${catCols}
        <td style="text-align: right; padding: 7px 8px; border: 1px solid #cbd5e1; font-weight: 900; background: #e0f2fe; color: #0369a1; font-family: monospace; font-size: 11px;">
          ${monthTotal > 0 ? monthTotal.toLocaleString('en-IN') : '-'}
        </td>
      </tr>
    `;
  }).join('');

  // Member photo vs blank initials
  const memberPhotoHtml = member.avatarUrl 
    ? `<img src="${member.avatarUrl}" style="width: 74px; height: 74px; border-radius: 12px; object-fit: cover; border: 2px solid #1e3a8a; flex-shrink: 0; box-shadow: 0 2px 6px rgba(0,0,0,0.1);" />`
    : `<div style="width: 74px; height: 74px; border-radius: 12px; background: #e2e8f0; border: 1.5px dashed #94a3b8; display: flex; align-items: center; justify-content: center; color: #64748b; font-weight: 900; font-size: 22px; flex-shrink: 0;">${member.name.charAt(0) || 'M'}</div>`;

  const orgLogoHtml = logoUrl 
    ? `<img src="${logoUrl}" style="width: 36px; height: 36px; border-radius: 6px; object-fit: cover; vertical-align: middle; margin-right: 6px; border: 1px solid #cbd5e1;" />`
    : '';

  return `
    <!DOCTYPE html>
    <html>
      <head>
        <title>Passbook Card • ${member.name} (${member.id})</title>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <style>
          @page { size: A4 portrait; margin: 12mm; }
          body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; color: #0f172a; }
          table { width: 100%; border-collapse: collapse; margin-top: 14px; }
          th { background: #1e293b; color: white; padding: 8px; font-size: 11px; text-transform: uppercase; border: 1px solid #0f172a; }
          .card { border: 1.5px solid #1e3a8a; border-radius: 12px; padding: 14px; margin-bottom: 14px; background: #f8fafc; }
          @media print {
            thead { display: table-row-group !important; }
            tr { page-break-inside: avoid !important; break-inside: avoid !important; }
          }
        </style>
      </head>
      <body>
        <div class="card">
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <div style="display: flex; align-items: center; gap: 14px;">
              ${memberPhotoHtml}
              <div>
                <div style="font-size: 11px; color: #475569; font-weight: bold; text-transform: uppercase; display: flex; align-items: center;">
                  ${orgLogoHtml} ${orgName} ${location ? `• 📍 ${location}` : ''}
                </div>
                <h1 style="margin: 2px 0 0 0; font-size: 20px; color: #1e3a8a; font-weight: 900;">${member.name}</h1>
                <div style="font-size: 11.5px; color: #334155; margin-top: 2px;">
                  Section: <b>${member.section || 'N/A'}</b> • Phone: <b>${member.fullPhone || `****${member.phoneLast4}`}</b>
                  ${member.dependents && member.dependents.length > 0 ? ` • Dependents: <b>${member.dependents.map(d => `${d.name} (${d.relation})`).join(', ')}</b>` : ''}
                </div>
              </div>
            </div>
            <div style="text-align: right;">
              <div style="font-size: 9.5px; color: #64748b; font-weight: bold; text-transform: uppercase;">UNIQUE MEMBER ID</div>
              <div style="font-size: 18px; font-weight: 900; font-family: monospace; color: #047857; background: #dcfce7; padding: 4px 10px; border-radius: 6px; border: 1px solid #86efac; margin-top: 3px;">${member.id}</div>
              <div style="font-size: 10px; color: #64748b; margin-top: 4px;">Statement Date: ${formatDateDDMMYYYY(new Date())}</div>
            </div>
          </div>
        </div>

        <table>
          <thead>
            <tr>
              <th style="width: 35px;">#</th>
              <th style="width: 80px;">MONTH</th>
              ${categories.map(c => `<th>${c.toUpperCase()}</th>`).join('')}
              <th style="width: 85px; background: #0284c7;">TOTAL</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml}
          </tbody>
          <tfoot>
            <tr style="background: #e2e8f0; font-weight: 900;">
              <td colspan="2" style="padding: 8px; border: 1px solid #0f172a; text-align: right; font-size: 11px;">G TOTAL:</td>
              ${categories.map(c => `
                <td style="text-align: right; padding: 8px; border: 1px solid #0f172a; font-family: monospace; font-size: 11px;">
                  ${categoryTotals[c] > 0 ? categoryTotals[c].toLocaleString('en-IN') : '-'}
                </td>
              `).join('')}
              <td style="text-align: right; padding: 8px; border: 1px solid #0f172a; font-weight: 900; background: #0284c7; color: white; font-family: monospace; font-size: 12px;">
                ₹${grandTotal.toLocaleString('en-IN')}
              </td>
            </tr>
          </tfoot>
        </table>
      </body>
    </html>
  `;
};

export const exportMemberPassbookVerticalPrint = (
  member: MemberRecord,
  categories: string[],
  transactions: Transaction[],
  orgName: string,
  logoUrl?: string,
  location?: string
) => {
  const html = generateMemberPassbookVerticalPrintHtml(member, categories, transactions, orgName, logoUrl, location);
  printHtmlSafely(html, `Passbook Card • ${member.name} (${member.id})`);
};

